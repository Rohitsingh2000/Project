
package database;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.JOptionPane;
public class DataBase {
    private static Scanner x;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
       String filepath="tutorial.txt";
       System.out.println("1- Read Record\n2- Save Record\n3- Remove Record");
               int choose=sc.nextInt();
       if(choose==1)
       {    System.out.println("Enter ID");
           String searchTerm=sc.next();
           readRecord(searchTerm,filepath);
       }
       else if(choose==2)
       {
           System.out.println("Enter ID");
       String ID=sc.next();
           System.out.println("Enter Name");
       String name=sc.next();
           System.out.println("Enter Age");
       String age=sc.next();
           saveRecord(ID,name,age,filepath);
       }
        else if(choose==3){
           System.out.println("Enter ID");
           String removeTerm=sc.next();
           removeRecord(filepath,removeTerm);
       }
    }
    public static void readRecord(String searchTerm,String filepath)
    { 
        boolean found=false;
        String ID="";String name1="";String age=""; 
        try{
          x=new Scanner (new File(filepath));
          x.useDelimiter("[,\n]");
          while(x.hasNext() &&!found )
          {
              ID=x.next();
              name1=x.next();
              age=x.next();
              if(ID.equals(searchTerm))
              {
                  found=true;
              }
        }
          if(found){
              JOptionPane.showMessageDialog(null,"ID:"+ ID +" Name: "+ name1 + " Age: "+age);
          }
          else{
             JOptionPane.showMessageDialog(null,"Record not found"); 
          }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error");
        }
    }
    public static void saveRecord(String ID,String name,String age,String filepath){
        try{
            FileWriter fw=new FileWriter(filepath,true);
            BufferedWriter bw=new BufferedWriter(fw);
            PrintWriter pw=new PrintWriter(bw);
            pw.println(ID+","+name+","+age);
            pw.flush();
            pw.close();
            
            JOptionPane.showMessageDialog(null, "Record saved");
        }
        catch(Exception e){
          JOptionPane.showMessageDialog(null, "Record not saved");  
        }
        
    }
    public static void removeRecord(String filepath,String removeTerm)
    {
      String tempFile="temp.txt";
      File oldFile=new File(filepath);
      File newFile=new File(tempFile);
      String ID="";String name="";String age="";
      try{
            FileWriter fw=new FileWriter(tempFile,true);
            BufferedWriter bw=new BufferedWriter(fw);
            PrintWriter pw=new PrintWriter(bw);
            x=new Scanner (new File(filepath));
            x.useDelimiter("[,\n]");
            while(x.hasNext())
          {
              ID=x.next();
              name=x.next();
              age=x.next();
              if(!ID.equals(removeTerm))
              {
                  pw.print(ID+","+name+","+age);
              }
          }
            x.close();
            pw.flush();
            pw.close();
            oldFile.delete();
            File dump=new File(filepath);
            newFile.renameTo(dump);
      }
      catch(Exception e)
      {
        JOptionPane.showMessageDialog(null,"Error");
      }
    }
}

